import { useNavigate } from 'react-router-dom';
import React, { useEffect, useState } from 'react';
import { Eye, EyeOff, Fingerprint, LockKeyhole, ShieldCheck, Sparkles } from 'lucide-react';
import { AuthService } from '../services/AuthService';
import { APP_VERSION_LABEL } from '../lib/version';
import { LightHighwayCanvas } from './auth/LightHighwayCanvas';
import { menuSections } from '../lib/navigation';
import type { UserAccount } from '../types';

/**
 * Solar Ember login presentation. Authentication is deliberately not simulated:
 * the form reports NOT_CONFIGURED until a real server-side provider is connected.
 */
export function LoginWorkspace({ onAuthenticated, tenantName, logoUrl, applyEnabled = true }: { onAuthenticated?: (user: UserAccount) => void; tenantName?: string; logoUrl?: string; applyEnabled?: boolean }) {
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [status, setStatus] = useState('');
  const [phase, setPhase] = useState(0);
  const [warp, setWarp] = useState(false);
  const [moduleLabel, setModuleLabel] = useState('');
  const timers = React.useRef<number[]>([]);
  useEffect(() => () => timers.current.forEach(window.clearTimeout), []);

  /** انتقال Warp: لوگو از دو طرف محو، دوربین به جلو، نام ماژول‌ها، سپس باز شدن دالان. فقط پس از احراز هویت واقعی (یا پیش‌نمایش حرکتی DEV بدون ورود) */
  const startWarp = (done: () => void) => {
    setWarp(true);
    const names = menuSections.flatMap(s => s.items.map(i => i.label)).slice(0, 6);
    names.forEach((n, i) => timers.current.push(window.setTimeout(() => setModuleLabel(n), 500 + i * 330)));
    timers.current.push(window.setTimeout(() => setModuleLabel(''), 500 + names.length * 330));
    timers.current.push(window.setTimeout(done, 3000));
  };

  useEffect(() => {
    const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    if (reduced) { setPhase(3); return; }
    const timers = [window.setTimeout(() => setPhase(1), 1000), window.setTimeout(() => setPhase(2), 2000), window.setTimeout(() => setPhase(3), 3000)];
    return () => timers.forEach(window.clearTimeout);
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('');
    const result = await AuthService.authenticate({ username: username.trim(), password });
    if (result.status === 'NOT_CONFIGURED') setStatus('ورود واقعی هنوز به سرویس احراز هویت امن متصل نشده است. هیچ ورود آزمایشی انجام نشد.');
    else if (result.status === 'AUTHENTICATED') startWarp(() => onAuthenticated?.(result.user));
    else setStatus('ورود انجام نشد. اطلاعات یا دسترسی ورود را بررسی کنید.');
  };

  return (
    <main className={`se-login-root${warp ? ' is-warp' : ''}`} dir="rtl">
      <div className="se-login-atmosphere" aria-hidden="true" />
      <div className="se-login-grid" aria-hidden="true" />
      <section className="se-login-scene" aria-label="معرفی برند اخوان">
        <LightHighwayCanvas className="se-highway-canvas" phase={phase} warp={warp} />
        <div className={`se-light-highway phase-${phase}`} aria-hidden="true">
          <i /><i /><i /><i /><i /><i /><i />
        </div>
        <svg className={`se-brand-mark phase-${phase}`} viewBox="0 0 160 130" role="img" aria-label="نشان حرف A">
          <defs>
            <linearGradient id="seMetal" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stopColor="#71364B"/><stop offset=".48" stopColor="#D5A15E"/><stop offset="1" stopColor="#FFF4D9"/></linearGradient>
            <filter id="seGlow"><feGaussianBlur stdDeviation="3.5" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
          </defs>
          <path className="se-a-shadow" d="M28 111 L79 14 L132 111 M48 75 L111 75" />
          <path className="se-a-stroke" d="M28 111 L79 14 L132 111 M48 75 L111 75" stroke="url(#seMetal)" filter="url(#seGlow)" />
          <circle className="se-a-flare" cx="79" cy="14" r="4" />
        </svg>
        <div className={`se-brand-copy phase-${phase}`}>
          <div className="se-brand-persian">گروه اخوان</div>
          <div className="se-brand-english">AKHAVAN <span>GROUP</span></div>
          <div className="se-brand-rule"><i /><b>CRM</b><i /></div>
          <div className="se-tagline-swap">
            <p className="se-brand-tagline-en" lang="en" dir="ltr">Next-generation technology designed to power peak organizational performance.</p>
            <p className="se-brand-tagline-fa" lang="fa">نسل جدید فناوری هوشمندسازی فروش و مدیریت، طراحی‌شده برای خلق برترین عملکرد سازمانی.</p>
          </div>
        </div>
        <div className="se-warp-text" aria-live="polite">{warp && <><strong>AKHAVAN CRM · Intelligence in Motion…</strong><span key={moduleLabel}>{moduleLabel}</span></>}</div>
        <div className="se-login-intelligence" aria-live="polite">{phase < 3 ? 'AKHAVAN CRM · Intelligence in Motion…' : 'قدرت تصمیم‌گیری، در حرکت'}</div>
      </section>

      <section className="se-login-panel">
        <div className="se-login-panel-brand"><span className="se-login-mini-mark">{logoUrl ? <img src={logoUrl} alt={tenantName || 'لوگو'} style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: 'inherit' }} /> : 'A'}</span><div><strong>ورود به AKHAVAN CRM</strong><span>{tenantName || 'فضای کاری سازمانی'}</span></div></div>
        <h1>خوش آمدید</h1>
        <p className="se-login-intro">برای ادامه، اطلاعات حساب سازمانی خود را وارد کنید.</p>
        <form onSubmit={submit} className="se-login-form">
          <label htmlFor="se-login-username">نام کاربری</label>
          <input id="se-login-username" autoComplete="username" value={username} onChange={e => setUsername(e.target.value)} placeholder="نام کاربری سازمانی" required />
          <label htmlFor="se-login-password">گذرواژه</label>
          <div className="se-password-wrap"><input id="se-login-password" autoComplete="current-password" type={showPassword ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} placeholder="گذرواژه" required /><button type="button" aria-label={showPassword ? 'پنهان کردن گذرواژه' : 'نمایش گذرواژه'} onClick={() => setShowPassword(v => !v)}>{showPassword ? <EyeOff size={18}/> : <Eye size={18}/>}</button></div>
          <button className="se-login-submit" type="submit"><LockKeyhole size={17}/> ورود امن به سامانه</button>
          {status && <p className="se-login-status" role="alert">{status}</p>}
        </form>
        <button className={`se-login-biometric${warp ? ' pulse' : ''}`} type="button" disabled title="پس از اتصال احراز هویت WebAuthn و سرویس سرور فعال می‌شود"><Fingerprint size={20}/> ورود با Face ID / اثر انگشت <span>در انتظار اتصال</span></button>
        <div className="se-login-not-configured"><ShieldCheck size={16}/><span>درگاه احراز هویت هنوز پیکربندی نشده است؛ این صفحه هیچ ورود جعلی یا دورزدن امنیتی انجام نمی‌دهد.</span></div>
        {import.meta.env.DEV && <button type="button" className="se-login-motion-preview" onClick={() => startWarp(() => { setWarp(false); setModuleLabel(''); })} disabled={warp}>پیش‌نمایش حرکت Warp (فقط توسعه؛ بدون ورود)</button>}
        {applyEnabled && (
          <aside className="se-apply-card" aria-label="ثبت‌نام و درخواست همکاری">
            <strong>متقاضی استخدام یا نیروی جدید هستید؟</strong>
            <span>بدون نیاز به حساب کاربری، اطلاعات و مدارک خود را ثبت کنید.</span>
            <button type="button" onClick={() => navigate('/apply')}>ثبت اطلاعات و درخواست همکاری</button>
          </aside>
        )}
        <div className="se-login-footer"><Sparkles size={14}/> Solar Ember · {APP_VERSION_LABEL}</div>
      </section>
    </main>
  );
}
