import { getTenantName } from '../lib/orgPolicy';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  Search, Bell, Plus, Menu, X, Home, Users, CheckSquare, MessagesSquare, ChevronLeft,
  FileText, UserPlus, ClipboardList, UserRound, Settings
} from 'lucide-react';
import { cn } from '../lib/utils';
import { AppState } from '../types';
import { Avatar } from './ui/Avatar';
import { NavigationDrawer } from './NavigationDrawer';
import { Sidebar } from './Sidebar';
import { AtmosphereLayer } from './AtmosphereLayer';
import { RBACService } from '../lib/rbac';
import { QuoteWizardModal } from './QuoteWizardModal';
import { menuSections, filterSections } from '../lib/navigation';
import { haptics } from '../lib/haptics';
import { computeMissing, getOnboardingConfig } from '../lib/onboarding';
import { ThemeToggle } from './ThemeToggle';

interface LayoutProps {
  children: React.ReactNode;
  onOpenSearch?: () => void;
  unreadNotificationsCount?: number;
  onOpenNotifications?: () => void;
  state?: AppState;
  updateState?: (updater: (draft: AppState) => AppState | void) => void;
}

const NAV_ITEMS = [
  { id: 'home', path: '/', label: 'خانه', icon: Home },
  { id: 'accounts', path: '/accounts', label: 'مشتریان', icon: Users },
  { id: 'tasks', path: '/tasks', label: 'وظایف', icon: CheckSquare },
  { id: 'groups', path: '/groups', label: 'تعاملات', icon: MessagesSquare },
] as const;

export function Layout({ children, onOpenSearch, unreadNotificationsCount = 0, onOpenNotifications, state, updateState }: LayoutProps) {
  const location = useLocation();
  const navigate = useNavigate();

  const [quickAddOpen, setQuickAddOpen] = useState(false);
  const [navDrawerOpen, setNavDrawerOpen] = useState(false);
  const [isQuoteWizardOpen, setIsQuoteWizardOpen] = useState(false);
  const [avatarMenuOpen, setAvatarMenuOpen] = useState(false);
  const [labelId, setLabelId] = useState<string | null>(null);
  const [labelTick, setLabelTick] = useState(0);
  const addBtnRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  const currentUser = state?.users?.find(u => u.id === state?.currentUserId);
  const currentRole = state?.roles?.find(r => r.id === currentUser?.roleId);
  const rbac = useMemo(() => (state ? new RBACService(state) : null), [state]);
  const canAccess = (tab: string) => (rbac ? rbac.canAccessWorkspace(tab as any) : true);
  const can = (perm: string) => (rbac ? rbac.hasPermission(perm as any) : true);
  const sections = useMemo(() => filterSections(menuSections, canAccess), [rbac]); // eslint-disable-line react-hooks/exhaustive-deps

  const activeCustomer = state?.accounts?.find(a => a.id === state?.activeContextAccountId);
  const myTasks = (state?.tasks || []).filter((t: any) => t.assigneeType !== 'GROUP' && t.assigneeId === state?.currentUserId);
  const sidebarStats = state ? { openTasks: myTasks.filter((t: any) => t.status !== 'COMPLETED').length, doneTasks: myTasks.filter((t: any) => t.status === 'COMPLETED').length, overdue: myTasks.filter((t: any) => t.slaStatus === 'BREACHED' && t.status !== 'COMPLETED').length } : undefined;
  const isHome = location.pathname === '/';
  const ob = getOnboardingConfig(state as any); const myFile: any = (state?.personnelFiles || []).find((f: any) => f.userId === state?.currentUserId);
  const fileMissing = state && ob.enabled && state.currentUserId && location.pathname !== '/personnel-file' && (!myFile || myFile.status !== 'APPROVED') ? computeMissing(myFile, ob).length : 0;
  const inChat = location.pathname.startsWith('/groups');
  const chatOpen = inChat && new URLSearchParams(location.search).get('c') !== null;
  const seg = isHome ? 'home' : location.pathname.split('/')[1];
  const activePageLabel = sections.flatMap(section => section.items).find(item => location.pathname === item.path || (item.path !== '/' && location.pathname.startsWith(item.path + '/')))?.label || (isHome ? 'خانه' : 'فضای کاری');

  // ---------- Quick Add: بستن با Escape، بازگشت فوکوس ----------
  const closeQuickAdd = () => { setQuickAddOpen(false); addBtnRef.current?.focus(); };
  useEffect(() => {
    if (!quickAddOpen) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') closeQuickAdd(); };
    window.addEventListener('keydown', onKey);
    panelRef.current?.querySelector<HTMLElement>('button')?.focus();
    return () => window.removeEventListener('keydown', onKey);
  }, [quickAddOpen]);
  useEffect(() => { setQuickAddOpen(false); setAvatarMenuOpen(false); }, [location.pathname]);

  // اکشن‌ها فقط از قابلیت‌ها و مجوزهای واقعی ساخته می‌شوند؛ هر کدام فرم واقعی همان ماژول را باز می‌کنند
  const quickItems = [
    can('quotes.create') && { id: 'quote', icon: FileText, label: 'صدور پیش‌فاکتور', hero: true, action: () => setIsQuoteWizardOpen(true) },
    { id: 'task', icon: CheckSquare, label: 'وظیفه جدید', action: () => navigate('/tasks?new=1') },
    can('accounts.edit') && { id: 'customer', icon: UserRound, label: 'مشتری جدید', action: () => navigate('/accounts?new=1') },
    can('leads.edit') && { id: 'lead', icon: UserPlus, label: 'سرنخ جدید', action: () => navigate('/leads?new=1') },
    (can('internal.view') || can('internal.manage')) && { id: 'request', icon: ClipboardList, label: 'درخواست سازمانی', action: () => navigate('/internal_automation?new=1') },
  ].filter(Boolean).slice(0, 5) as { id: string; icon: React.ElementType; label: string; hero?: boolean; action: () => void }[];

  const toggleQuickAdd = () => { haptics.selection(); setQuickAddOpen(p => !p); };
  const goNav = (id: string, path: string) => {
    haptics.selection(); setLabelId(id); setLabelTick(t => t + 1); navigate(path);
  };

  // ---------- Swipe راست→چپ در Home برای بازکردن اینباکس (چت) ----------
  const swipe = useRef<{ x: number; y: number; t: number } | null>(null);
  const blocked = (el: EventTarget | null) => !!(el as HTMLElement | null)?.closest?.('input,textarea,select,table,[contenteditable],[data-no-swipe],[role="slider"]');
  const onPointerDown = (e: React.PointerEvent) => {
    if (!isHome || e.pointerType === 'mouse' || blocked(e.target)) { swipe.current = null; return; }
    const edge = 24; if (e.clientX < edge || e.clientX > window.innerWidth - edge) { swipe.current = null; return; }
    swipe.current = { x: e.clientX, y: e.clientY, t: Date.now() };
  };
  const onPointerUp = (e: React.PointerEvent) => {
    const s = swipe.current; swipe.current = null; if (!s) return;
    const dx = e.clientX - s.x, dy = e.clientY - s.y;
    if (dx < -80 && Math.abs(dy) < 40 && Date.now() - s.t < 600) { haptics.light(); navigate('/groups'); }
  };

  // ---------- Swipe-down برای بستن پنل Quick Add ----------
  const panelDrag = useRef<number | null>(null);

  const topButtons = (
    <>
      <button onClick={onOpenSearch} aria-label="جستجو" className="se-float-btn se-interactive se-pressable"><Search className="h-[18px] w-[18px]" /></button>
      <button onClick={() => navigate('/groups')} aria-label="چت و پیام‌ها" className="se-float-btn se-interactive se-pressable"><MessagesSquare className="h-[18px] w-[18px]" /></button>
      <button onClick={onOpenNotifications} aria-label={unreadNotificationsCount > 0 ? `اعلان‌ها (${unreadNotificationsCount} خوانده‌نشده)` : 'اعلان‌ها'} className="se-float-btn se-interactive se-pressable">
        <Bell className="h-[18px] w-[18px]" />
        {unreadNotificationsCount > 0 && (
          <span className="absolute -end-1 -top-1 min-w-5 rounded-full bg-coral px-1.5 py-0.5 text-center text-[10px] font-bold leading-none text-white ring-2 ring-white">{unreadNotificationsCount.toLocaleString('fa-IR')}</span>
        )}
      </button>
      <div className="relative">
        <button onClick={() => setAvatarMenuOpen(o => !o)} aria-label="منوی کاربر" aria-expanded={avatarMenuOpen} aria-haspopup="menu" className="se-float-btn se-interactive se-pressable !p-0.5">
          <Avatar name={currentUser?.name || 'کاربر'} src={currentUser?.avatar} size="sm" />
        </button>
        {avatarMenuOpen && (
          <>
            <div className="fixed inset-0 z-40" onClick={() => setAvatarMenuOpen(false)} />
            <div role="menu" className="glass-strong se-panel-enter absolute end-0 top-[calc(100%+8px)] z-50 w-56 overflow-hidden rounded-3xl p-2">
              <div className="px-3 py-2"><div className="truncate text-xs font-bold text-ink">{currentUser?.name || 'کاربر سیستم'}</div><div className="truncate text-[11px] text-ink-soft">{currentRole?.name || ''}</div></div>
              <button role="menuitem" onClick={() => navigate('/profile')} className="flex w-full cursor-pointer items-center gap-2 rounded-2xl px-3 py-2.5 text-start text-xs font-bold text-ink hover:bg-primary/[.07]"><UserRound size={15} />پروفایل من</button>
              <div className="flex items-center justify-between px-3 py-2"><span className="text-xs font-bold text-ink">تم</span><ThemeToggle /></div>
              {canAccess('settings') && <button role="menuitem" onClick={() => navigate('/settings')} className="flex w-full cursor-pointer items-center gap-2 rounded-2xl px-3 py-2.5 text-start text-xs font-bold text-ink hover:bg-primary/[.07]"><Settings size={15} />تنظیمات</button>}
            </div>
          </>
        )}
      </div>
    </>
  );

  return (
    <div className="relative h-[100dvh] w-full overflow-hidden bg-transparent font-premium" dir="rtl">
      <a href="#main-content" className="sr-only focus:not-sr-only focus:fixed focus:start-3 focus:top-3 focus:z-[100] focus:rounded-full focus:bg-primary focus:px-4 focus:py-2 focus:text-xs focus:font-bold focus:text-white">پرش به محتوای اصلی</a>
      <AtmosphereLayer />
      <div className={cn('relative z-10 flex h-full w-full origin-left overflow-hidden transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]',
        navDrawerOpen ? 'pointer-events-none scale-[0.92] rounded-[2rem] opacity-70 shadow-2xl' : 'scale-100')}>

        <Sidebar sections={sections} user={currentUser} roleName={currentRole?.name} stats={sidebarStats} />

        <div className="relative flex min-w-0 flex-1 flex-col overflow-hidden">
          {/* در Home هدر مستقل وجود ندارد؛ کنترل‌های شناور و مجزا */}
          {isHome ? (
            <div className="pointer-events-none absolute inset-x-0 top-0 z-30 flex items-center justify-between gap-3 px-3.5 pt-[calc(env(safe-area-inset-top,0px)+10px)] sm:px-5">
              <button onClick={() => setNavDrawerOpen(true)} aria-label="منوی اصلی" className="se-float-btn se-interactive se-pressable pointer-events-auto lg:invisible"><Menu className="h-5 w-5" /></button>
              <div className="pointer-events-auto flex items-center gap-2">{topButtons}</div>
            </div>
          ) : (
            <header className="sticky top-0 z-30 flex shrink-0 items-center gap-3 border-b border-border/60 bg-surface/75 px-3.5 pb-2 pt-[calc(env(safe-area-inset-top,0px)+10px)] shadow-sm backdrop-blur-xl sm:px-5">
              <button onClick={() => setNavDrawerOpen(true)} aria-label="منوی اصلی" className="se-float-btn se-interactive se-pressable lg:hidden"><Menu className="h-5 w-5" /></button>
              <div className="min-w-0 flex-1 px-1 lg:px-0">
                <h1 className="truncate text-sm font-extrabold tracking-tight text-ink">{activePageLabel}</h1>
                <p className="mt-0.5 hidden truncate text-[10px] font-medium text-ink-soft sm:block">{getTenantName(state) ? `${getTenantName(state)} · ` : ''}فضای کاری یکپارچه</p>
              </div>
              <div className="flex items-center gap-2">{topButtons}</div>
            </header>
          )}

          <main id="main-content" tabIndex={-1} className="w-full flex-1 overflow-y-auto outline-none" onPointerDown={onPointerDown} onPointerUp={onPointerUp} onPointerCancel={() => { swipe.current = null; }}>
            <div className={cn('mx-auto min-h-full w-full max-w-[var(--content-max)]', inChat ? 'pb-0' : 'pb-[calc(env(safe-area-inset-bottom,0px)+118px)] lg:pb-24', isHome && 'pt-[calc(env(safe-area-inset-top,0px)+62px)]')}>
              {activeCustomer && seg === 'accounts' && (
                <div className="flex items-center gap-1.5 px-4 pb-1 pt-2 text-xs">
                  <ChevronLeft className="h-4 w-4 text-ink-soft" />
                  <span className="font-medium text-ink-soft">مشتری:</span>
                  <div className="glass flex items-center gap-1.5 rounded-full py-0.5 pe-1 ps-3">
                    <span className="max-w-[180px] truncate text-[11px] font-extrabold text-ink">{activeCustomer.name}</span>
                    <button aria-label="خروج از زمینه مشتری" onClick={() => updateState && updateState(d => { d.activeContextAccountId = null; d.activeContextCustomerId = null; })}
                      className="grid h-6 w-6 cursor-pointer place-items-center rounded-full text-ink-soft hover:bg-ink/10 hover:text-ink"><X className="h-3 w-3" /></button>
                  </div>
                </div>
              )}
              {fileMissing > 0 && myFile?.status !== 'SUBMITTED_FOR_REVIEW' && (
                <button onClick={() => navigate('/personnel-file')} className="se-interactive mx-3 mt-2 flex min-h-[44px] w-[calc(100%-1.5rem)] cursor-pointer items-center justify-between rounded-2xl border border-warning-line bg-warning-soft px-4 text-start text-xs font-bold text-warning"><span>{myFile?.status === 'NEEDS_CORRECTION' ? 'پرونده پرسنلی شما نیازمند اصلاح است' : `پرونده پرسنلی شما ناقص است (${fileMissing.toLocaleString('fa-IR')} مورد)`}</span><span>تکمیل پرونده ←</span></button>
              )}
              {children}
            </div>
          </main>
        </div>

        {/* ---------- ناوبری پایین: کپسول چهارآیکونی + کپسول + مستقل ---------- */}
        <div className={cn('se-bottom-nav lg:hidden', chatOpen && '!hidden')}>
          <nav aria-label="ناوبری اصلی" className="se-nav-capsule">
            {NAV_ITEMS.map(i => {
              const on = i.id === seg; const Icon = i.icon;
              return (
                <button key={i.id} onClick={() => goNav(i.id, i.path)} aria-current={on ? 'page' : undefined} aria-label={i.label} title={i.label} className="se-nav-item se-pressable">
                  <Icon strokeWidth={on ? 2.3 : 1.75} className="h-[21px] w-[21px]" />
                  {labelId === i.id && <span key={labelTick} className="se-nav-label is-visible" aria-hidden>{i.label}</span>}
                </button>
              );
            })}
          </nav>
          <button ref={addBtnRef} onClick={toggleQuickAdd} aria-label="افزودن سریع" aria-expanded={quickAddOpen} aria-haspopup="dialog" className="se-add-capsule se-pressable se-interactive">
            <Plus strokeWidth={2.3} className={cn('h-6 w-6 transition-transform duration-300', quickAddOpen && 'rotate-45')} />
          </button>
        </div>

        {/* دسکتاپ: دکمه + شناور گوشه پایین (همان پنل) */}
        <button onClick={toggleQuickAdd} aria-label="افزودن سریع" aria-expanded={quickAddOpen} aria-haspopup="dialog"
          className="se-add-capsule se-pressable se-interactive fixed bottom-8 left-8 z-20 hidden lg:inline-flex"><Plus strokeWidth={2.3} className={cn('h-6 w-6 transition-transform duration-300', quickAddOpen && 'rotate-45')} /></button>

        {/* ---------- پنل Quick Add ---------- */}
        {quickAddOpen && (
          <>
            <div className="fixed inset-0 z-[var(--z-overlay)] backdrop-blur-[6px]" style={{ background: 'var(--scrim)' }} onClick={closeQuickAdd} aria-hidden />
            <div ref={panelRef} role="dialog" aria-modal="true" aria-label="افزودن سریع" onAnimationEnd={() => haptics.light()} className="se-action-panel se-spring-up lg:!bottom-24 lg:!left-8"
              onPointerDown={e => { panelDrag.current = e.clientY; }}
              onPointerUp={e => { if (panelDrag.current !== null && e.clientY - panelDrag.current > 70) closeQuickAdd(); panelDrag.current = null; }}
              onPointerCancel={() => { panelDrag.current = null; }}>
              <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-border-strong" aria-hidden />
              <div className="grid grid-cols-3 gap-2">
                {quickItems.map((item, idx) => (
                  <button key={item.id} style={{ ['--i' as any]: idx }} onClick={() => { haptics.light(); closeQuickAdd(); item.action(); }}
                    className="se-action-item group flex min-h-[44px] cursor-pointer flex-col items-center gap-1.5 rounded-2xl p-2 hover:bg-primary/[.07]">
                    <span className={cn('grid h-12 w-12 place-items-center rounded-full transition-transform group-active:scale-95', item.hero ? 'bg-primary text-white shadow-lux' : 'glass text-primary')}>
                      <item.icon strokeWidth={2} className="h-5 w-5" />
                    </span>
                    <span className="text-center text-[11px] font-bold leading-tight text-ink">{item.label}</span>
                  </button>
                ))}
              </div>
              <button onClick={closeQuickAdd} className="mt-2 w-full cursor-pointer rounded-full py-2 text-[11px] font-bold text-ink-soft hover:bg-ink/10">بستن</button>
            </div>
          </>
        )}
      </div>

      <NavigationDrawer isOpen={navDrawerOpen} onClose={() => setNavDrawerOpen(false)} state={state} />

      {updateState && state && (
        <QuoteWizardModal isOpen={isQuoteWizardOpen} onClose={() => setIsQuoteWizardOpen(false)} state={state} updateState={updateState} onQuoteCreated={() => navigate('/quotes')} />
      )}
    </div>
  );
}
