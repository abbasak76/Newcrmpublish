import React, { useId } from 'react';
import { cn } from '../../lib/utils';

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export const Input: React.FC<InputProps> = ({
  label,
  error,
  className = '',
  ...props
}) => {
  const uid = useId();
  const id = (props.id as string) || uid;
  return (
    <div className="space-y-1 text-right" dir="rtl">
      {label && <label htmlFor={id} className="block font-bold text-text-main text-xs mb-1">{label}</label>}
      <input
        id={id}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? `${id}-err` : undefined}
        className={cn(
          'w-full bg-white border border-border rounded-2xl min-h-[44px] p-3 text-xs font-medium text-text-main outline-none focus:border-accent focus:ring-2 focus:ring-accent/30 shadow-subtle transition-all',
          error ? 'border-danger bg-danger-soft/40' : '',
          className
        )}
        {...props}
      />
      {error && <span id={`${id}-err`} role="alert" className="text-[11px] text-danger block mt-0.5">{error}</span>}
    </div>
  );
};
