import React, { useState, useRef, useEffect } from 'react';
import { 
  getJalaliDate, 
  jalaliToGregorianISO, 
  formatJalaliDate, 
  JALALI_MONTH_NAMES, 
  getJalaliMonthDays, 
  toPersianDigits 
} from '../../lib/jalali';
import { Calendar as CalendarIcon, ChevronDown, Check, X } from 'lucide-react';

interface CustomDatePickerProps {
  value: string; // ISO date string (YYYY-MM-DD)
  onChange: (date: string) => void;
  className?: string;
  placeholder?: string;
  calendarType?: 'jalali' | 'gregorian';
}

export const CustomDatePicker: React.FC<CustomDatePickerProps> = ({
  value,
  onChange,
  className = '',
  placeholder = 'انتخاب تاریخ',
  calendarType = 'jalali',
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Parse current value or fallback to today
  const activeDate = value ? new Date(value) : new Date();
  const validDate = isNaN(activeDate.getTime()) ? new Date() : activeDate;
  
  const initialJalali = getJalaliDate(validDate);
  const [selectedYear, setSelectedYear] = useState<number>(initialJalali.jy);
  const [selectedMonth, setSelectedMonth] = useState<number>(initialJalali.jm);
  const [selectedDay, setSelectedDay] = useState<number>(initialJalali.jd);

  // Sync internal state when external value changes
  useEffect(() => {
    if (value) {
      const d = new Date(value);
      if (!isNaN(d.getTime())) {
        const j = getJalaliDate(d);
        setSelectedYear(j.jy);
        setSelectedMonth(j.jm);
        setSelectedDay(j.jd);
      }
    }
  }, [value]);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const daysInCurrentMonth = getJalaliMonthDays(selectedYear, selectedMonth);

  const handleSelectDay = (day: number) => {
    setSelectedDay(day);
    const iso = jalaliToGregorianISO(selectedYear, selectedMonth, day);
    onChange(iso);
    setIsOpen(false);
  };

  const handleQuickSelect = (daysOffset: number) => {
    const target = new Date();
    target.setDate(target.getDate() + daysOffset);
    const j = getJalaliDate(target);
    setSelectedYear(j.jy);
    setSelectedMonth(j.jm);
    setSelectedDay(j.jd);
    const iso = jalaliToGregorianISO(j.jy, j.jm, j.jd);
    onChange(iso);
    setIsOpen(false);
  };

  const formattedDisplay = value 
    ? (calendarType === 'jalali' 
        ? formatJalaliDate(value, { format: 'full' })
        : new Date(value).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }))
    : placeholder;

  // Years range (1400 to 1410)
  const years = Array.from({ length: 11 }, (_, i) => 1400 + i);

  return (
    <div className={`relative ${className}`} ref={containerRef} dir="rtl">
      {/* Trigger Button */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full bg-white border border-border hover:border-primary rounded-xl p-2.5 text-xs font-bold text-text-main flex items-center justify-between shadow-xs transition-colors cursor-pointer outline-none focus:ring-1 focus:ring-primary"
      >
        <div className="flex items-center gap-2 truncate">
          <CalendarIcon className="w-4 h-4 text-primary shrink-0" />
          <span className="truncate">{formattedDisplay}</span>
        </div>
        <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {/* Floating Jalali Calendar Popover */}
      {isOpen && (
        <div className="absolute z-50 mt-1 right-0 w-80 bg-white border border-slate-200 rounded-2xl shadow-xl p-3 animate-in fade-in zoom-in-95 duration-150">
          {/* Header Controls: Year & Month Selectors */}
          <div className="flex items-center justify-between gap-2 border-b border-slate-100 pb-2.5 mb-2.5">
            <select
              value={selectedMonth}
              onChange={e => {
                const m = Number(e.target.value);
                setSelectedMonth(m);
                const maxDays = getJalaliMonthDays(selectedYear, m);
                const safeDay = Math.min(selectedDay, maxDays);
                setSelectedDay(safeDay);
                onChange(jalaliToGregorianISO(selectedYear, m, safeDay));
              }}
              className="bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold px-2 py-1.5 outline-none cursor-pointer flex-1"
            >
              {JALALI_MONTH_NAMES.map((name, idx) => (
                <option key={idx} value={idx + 1}>
                  {name}
                </option>
              ))}
            </select>

            <select
              value={selectedYear}
              onChange={e => {
                const y = Number(e.target.value);
                setSelectedYear(y);
                const maxDays = getJalaliMonthDays(y, selectedMonth);
                const safeDay = Math.min(selectedDay, maxDays);
                setSelectedDay(safeDay);
                onChange(jalaliToGregorianISO(y, selectedMonth, safeDay));
              }}
              className="bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold px-2 py-1.5 outline-none cursor-pointer w-24 font-mono"
            >
              {years.map(y => (
                <option key={y} value={y}>
                  {toPersianDigits(y)}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Days Grid */}
          <div className="grid grid-cols-7 gap-1 text-center mb-3">
            {['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'].map((d, i) => (
              <span key={i} className="text-[10px] font-black text-slate-400 py-1">
                {d}
              </span>
            ))}
            {Array.from({ length: daysInCurrentMonth }, (_, i) => i + 1).map(day => {
              const isSelected = day === selectedDay;
              return (
                <button
                  type="button"
                  key={day}
                  onClick={() => handleSelectDay(day)}
                  className={`h-7 rounded-lg text-xs font-bold transition-all flex items-center justify-center cursor-pointer ${
                    isSelected
                      ? 'bg-primary text-white shadow-xs font-black'
                      : 'hover:bg-slate-100 text-slate-700'
                  }`}
                >
                  {toPersianDigits(day)}
                </button>
              );
            })}
          </div>

          {/* Quick Presets */}
          <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
            <span className="text-slate-400 text-[10px] font-bold">انتخاب سریع:</span>
            <div className="flex gap-1.5">
              <button
                type="button"
                onClick={() => handleQuickSelect(0)}
                className="px-2 py-0.5 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold"
              >
                امروز
              </button>
              <button
                type="button"
                onClick={() => handleQuickSelect(1)}
                className="px-2 py-0.5 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold"
              >
                فردا
              </button>
              <button
                type="button"
                onClick={() => handleQuickSelect(7)}
                className="px-2 py-0.5 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold"
              >
                هفته بعد
              </button>
              <button
                type="button"
                onClick={() => handleQuickSelect(30)}
                className="px-2 py-0.5 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold"
              >
                یک ماه بعد
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
