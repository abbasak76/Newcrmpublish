import React, { useEffect, useRef } from 'react';
import { cn } from '../../lib/utils';
import { X, User, ChevronLeft } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Avatar } from './Avatar';
import { APP_VERSION_LABEL } from '../../lib/version';

export interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  maxWidth?: 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl';
  size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl';
  className?: string;
}

export const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  title,
  subtitle,
  children,
  footer,
  maxWidth,
  size,
  className,
}) => {
  const modalRef = useRef<HTMLDivElement>(null);
  const effectiveSize = size || maxWidth || 'lg';
  // onClose در ref نگه داشته می‌شود تا رندر مجدد والد، فوکوس کاربر را به اولین فیلد برنگرداند
  const sheetDrag = useRef<number | null>(null);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onCloseRef.current();
      
      if (e.key === 'Tab' && modalRef.current) {
        const focusableElements = modalRef.current.querySelectorAll(
          'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'
        );
        if (focusableElements.length === 0) return;
        
        const firstElement = focusableElements[0] as HTMLElement;
        const lastElement = focusableElements[focusableElements.length - 1] as HTMLElement;

        if (e.shiftKey) {
          if (document.activeElement === firstElement) {
            lastElement.focus();
            e.preventDefault();
          }
        } else {
          if (document.activeElement === lastElement) {
            firstElement.focus();
            e.preventDefault();
          }
        }
      }
    };

    const opener = document.activeElement as HTMLElement | null;
    let timer: ReturnType<typeof setTimeout> | undefined;
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
      timer = setTimeout(() => {
        const firstInput = modalRef.current?.querySelector('input, textarea, select, button') as HTMLElement;
        if (firstInput && !modalRef.current?.contains(document.activeElement)) firstInput.focus();
      }, 100);
    }
    return () => {
      if (timer) clearTimeout(timer);
      document.body.style.overflow = '';
      window.removeEventListener('keydown', handleKeyDown);
      if (isOpen && opener && document.contains(opener)) opener.focus();
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const widthClasses = {
    sm: 'max-w-sm',
    md: 'max-w-md',
    lg: 'max-w-lg',
    xl: 'max-w-xl',
    '2xl': 'max-w-2xl',
    '3xl': 'max-w-3xl',
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center p-0 sm:items-center sm:p-4" dir="rtl">
      <div onClick={onClose} className="fixed inset-0 bg-text-main/40 backdrop-blur-sm transition-opacity animate-in fade-in" />
      <div
        ref={modalRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-title"
        className={cn(
          "se-sheet relative w-full bg-surface/95 backdrop-blur-2xl shadow-modal border border-border overflow-hidden z-10 flex flex-col max-sm:rounded-t-[32px] max-sm:rounded-b-none max-sm:max-h-[90dvh] sm:rounded-[28px] sm:max-h-[88vh] sm:animate-in sm:zoom-in-95",
          widthClasses[effectiveSize],
          className
        )}
      >
        <div className="se-sheet-handle flex w-full justify-center pb-1 pt-3 sm:hidden touch-none"
          aria-label="برای بستن پنجره به پایین بکشید"
          onPointerDown={e => { sheetDrag.current = e.clientY; (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); if (modalRef.current) modalRef.current.style.transition = 'none'; }}
          onPointerMove={e => { if (sheetDrag.current !== null && modalRef.current) { const delta = e.clientY - sheetDrag.current; const dy = delta >= 0 ? delta : -Math.pow(Math.abs(delta), 0.72); modalRef.current.style.transform = `translateY(${dy}px)`; } }}
          onPointerUp={e => { const dy = sheetDrag.current !== null ? e.clientY - sheetDrag.current : 0; sheetDrag.current = null; if (modalRef.current) { modalRef.current.style.transition = 'transform 340ms cubic-bezier(0.22, 1.2, 0.36, 1)'; modalRef.current.style.transform = ''; } if (dy > 110) onCloseRef.current(); }}
          onPointerCancel={() => { sheetDrag.current = null; if (modalRef.current) { modalRef.current.style.transition = 'transform 280ms cubic-bezier(0.22, 1.2, 0.36, 1)'; modalRef.current.style.transform = ''; } }}>
          <div className="h-1.5 w-12 rounded-full bg-ink/15" />
        </div>
        <div className="flex items-center justify-between px-5 py-4 border-b border-border bg-canvas/70 shrink-0">
          <div>
            <h3 id="modal-title" className="text-base font-extrabold text-text-main leading-tight">{title}</h3>
            {subtitle && <p className="text-xs text-text-secondary mt-0.5">{subtitle}</p>}
          </div>
          <button onClick={onClose} className="p-1.5 text-text-secondary hover:text-text-main rounded-xl hover:bg-border transition-colors cursor-pointer" aria-label="بستن">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-5 overflow-y-auto no-scrollbar space-y-4 flex-1">
          {children}
        </div>
        {footer && (
          <div className="px-5 py-3.5 border-t border-border bg-surface/95 backdrop-blur-md shrink-0 flex items-center justify-end gap-2.5 sticky bottom-0 z-20">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
};

export interface SideDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  state?: any;
  title?: string;
  subtitle?: string;
  width?: 'sm' | 'md' | 'lg' | string;
  children?: React.ReactNode;
}

export const SideDrawer: React.FC<SideDrawerProps> = ({ isOpen, onClose, state, title, subtitle, children }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const path = location.pathname.split('/')[1] || 'home';

  if (!isOpen) return null;

  if (children) {
    return (
      <div className="fixed inset-0 z-50 overflow-hidden" dir="rtl">
        <div onClick={onClose} className="fixed inset-0 bg-text-main/40 backdrop-blur-xs transition-opacity" />
        <div className="fixed inset-y-0 right-0 z-50 flex">
          <div
            className={cn(
              "h-full bg-white shadow-[-20px_0_50px_rgba(0,0,0,0.1)] border-l border-slate-200 flex flex-col animate-in slide-in-from-right duration-300",
              "w-[85vw] sm:w-[420px]"
            )}
          >
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="text-base font-extrabold text-text-main">{title || 'منو'}</h3>
                {subtitle && <p className="text-xs text-text-secondary mt-0.5">{subtitle}</p>}
              </div>
              <button onClick={onClose} className="p-1.5 text-text-secondary hover:text-text-main rounded-xl hover:bg-slate-100 transition-colors cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-5 no-scrollbar">
              {children}
            </div>
          </div>
        </div>
      </div>
    );
  }

  const currentUser = state?.users?.find((u: any) => u.id === state?.currentUserId);
  const currentRole = state?.roles?.find((r: any) => r.id === currentUser?.roleId);

  const menuGroups = [
    {
      title: 'فروش و مشتریان',
      items: [
        { id: 'home', label: 'داشبورد اصلی' },
        { id: 'accounts', label: 'مشتریان و حساب‌ها' },
        { id: 'opportunities', label: 'فرصت‌های فروش' },
      ]
    },
    {
      title: 'عملیات و مالی',
      items: [
        { id: 'quotes', label: 'پیش‌فاکتورها' },
        { id: 'finance', label: 'امور مالی و وصولی' },
        { id: 'tasks', label: 'وظایف و پیگیری‌ها' },
      ]
    }
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-hidden" dir="rtl">
      <div onClick={onClose} className="fixed inset-0 z-40 bg-black/20 backdrop-blur-xs transition-opacity" />
      <div className="fixed inset-y-0 right-0 z-50 flex">
        <div
          className={cn(
            "h-full bg-white/85 backdrop-blur-3xl shadow-[-20px_0_50px_rgba(0,0,0,0.1)] border-l border-white/50 flex flex-col animate-in slide-in-from-right duration-400 ease-[cubic-bezier(0.16,1,0.3,1)]",
            "w-[80vw] md:w-[35vw] lg:w-[26vw]" 
          )}
        >
          {/* هدر منوی کشویی و اطلاعات کاربر */}
          <div className="px-6 py-6 border-b border-slate-200/60 bg-gradient-to-b from-slate-50/50 to-transparent">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-lg font-extrabold text-text-main tracking-tight">AKHAVAN CRM</h2>
                <p className="text-[11px] text-text-secondary font-medium">سیستم جامع مدیریت بازرگانی</p>
              </div>
              <button 
                onClick={onClose}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {currentUser && (
              <div 
                onClick={() => { navigate('/profile'); onClose(); }}
                className="flex items-center gap-3 p-3 bg-white border border-slate-200/80 rounded-2xl shadow-xs hover:border-primary/40 transition-all cursor-pointer group"
              >
                <Avatar name={currentUser.name || "کاربر"} size="sm" />
                <div className="flex-1 min-w-0">
                  <h4 className="text-xs font-bold text-text-main truncate group-hover:text-primary transition-colors">
                    {currentUser.name}
                  </h4>
                  <p className="text-[10px] text-text-secondary truncate mt-0.5">
                    {currentRole?.name || 'مدیر سیستم'}
                  </p>
                </div>
                <ChevronLeft className="w-4 h-4 text-slate-400 group-hover:text-primary transition-colors" />
              </div>
            )}
          </div>

          {/* لیست منوها با رنگ بنفش اختصاصی برای آیتم فعال */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6 no-scrollbar">
            {menuGroups.map((group, idx) => (
              <div key={idx}>
                <h4 className="text-[10px] font-extrabold text-text-secondary tracking-wider mb-3 px-1 uppercase opacity-80">
                  {group.title}
                </h4>
                <div className="space-y-1.5">
                  {group.items.map((item) => {
                    const isActive = path === item.id;
                    return (
                      <button 
                        key={item.id} 
                        onClick={() => { navigate(item.id === 'home' ? '/' : `/${item.id}`); onClose(); }} 
                        className={cn(
                          "w-full flex items-center justify-between px-4 py-3 rounded-2xl transition-all duration-300 text-right cursor-pointer group",
                          isActive 
                            ? "bg-primary text-white shadow-md shadow-primary/25 font-extrabold" 
                            : "text-text-main hover:bg-slate-100/70 font-semibold"
                        )}
                      >
                        <span className={cn("text-xs", isActive ? "text-white" : "text-slate-700 group-hover:text-primary")}>
                          {item.label}
                        </span>
                        {isActive && (
                          <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          {/* فوتر منو */}
          <div className="p-4 border-t border-slate-200/60 bg-slate-50/50 text-center">
            <span className="text-[10px] text-slate-400 font-mono">{APP_VERSION_LABEL}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
