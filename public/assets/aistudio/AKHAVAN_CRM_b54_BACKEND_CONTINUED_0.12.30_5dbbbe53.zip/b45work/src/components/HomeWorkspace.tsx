import React from 'react';
import { useNavigate } from 'react-router-dom';
import { AppState } from '../types';
import { CheckSquare, Clock, AlertTriangle, Building2, ChevronLeft, Calendar, ListChecks, CalendarCheck } from 'lucide-react';
import { cn } from '../lib/utils';

const greeting = (h: number) => (h < 5 ? 'شب بخیر' : h < 12 ? 'صبح بخیر' : h < 17 ? 'ظهر بخیر' : h < 20 ? 'عصر بخیر' : 'شب بخیر');
const fa = (n: number) => n.toLocaleString('fa-IR');

interface StatProps { label: string; value: number; hint: string; icon: React.ElementType; tone: 'danger' | 'warning' | 'primary' | 'success'; onClick: () => void; index: number }
const TONES = {
  danger: 'bg-danger-soft text-danger', warning: 'bg-warning-soft text-warning', primary: 'bg-primary/10 text-primary', success: 'bg-success-soft text-success',
} as const;
function StatCard({ label, value, hint, icon: Icon, tone, onClick, index }: StatProps) {
  return (
    <button onClick={onClick} style={{ ['--i' as any]: index }}
      className="se-card anim-rise se-interactive se-pressable flex min-h-[44px] cursor-pointer flex-col gap-2 p-3.5 text-start hover:-translate-y-0.5 hover:shadow-raised">
      <div className="flex items-center justify-between">
        <span className="text-xs font-bold text-text-secondary">{label}</span>
        <span className={cn('grid h-8 w-8 place-items-center rounded-xl', TONES[tone])}><Icon size={16} /></span>
      </div>
      <span className="text-2xl font-black leading-none tracking-tight text-text-main">{fa(value)}</span>
      <span className="text-[11px] font-medium text-text-secondary">{hint}</span>
    </button>
  );
}

function SectionTitle({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  return (
    <div className="flex items-center justify-between px-0.5">
      <h2 className="text-sm font-extrabold text-text-main">{title}</h2>
      {action && <button onClick={onAction} className="flex min-h-[44px] cursor-pointer items-center gap-0.5 px-1 text-[11px] font-bold text-primary hover:underline">{action}<ChevronLeft size={13} /></button>}
    </div>
  );
}

export function HomeWorkspace({ state }: { state: AppState }) {
  const navigate = useNavigate();
  const currentUser = state.users.find(u => u.id === state.currentUserId);
  const now = new Date();
  const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;

  const myTasks = (state.tasks || []).filter(t => t.assigneeId === state.currentUserId && t.status !== 'COMPLETED');
  const overdueTasks = myTasks.filter(t => t.dueDate && t.dueDate < today);
  const pendingApprovals = (state.internalRequests || []).filter((r: any) => r.currentAssigneeId === state.currentUserId && r.status === 'IN_REVIEW');
  const todayActivities = (state.activities || []).filter(a => a.ownerId === state.currentUserId && a.dateTime.startsWith(today));
  const todayMeetings = (state.internalMeetings || []).filter((m: any) => (m.organizerId === state.currentUserId || m.participantIds?.includes(state.currentUserId || '')) && m.date === today);
  const recentAccounts = [...(state.accounts || [])].sort((a: any, b: any) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()).slice(0, 5);
  const todayDateStr = new Intl.DateTimeFormat('fa-IR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }).format(now);
  const todayCount = todayMeetings.length + todayActivities.length;

  return (
    <div className="flex-1 space-y-5 overflow-y-auto bg-transparent p-3.5 pb-24 font-premium sm:p-5" dir="rtl">
      {/* سلام و خلاصه روز (بدون هدر مستقل) */}
      <section data-tour="header-user" className="se-card se-panel-enter relative overflow-hidden p-5">
        <div aria-hidden className="pointer-events-none absolute -top-16 end-[-40px] h-44 w-44 rounded-full bg-gold/25 blur-3xl" />
        <p className="relative flex items-center gap-1.5 text-xs font-medium text-text-secondary"><Calendar size={13} className="text-primary" />{todayDateStr}</p>
        <h1 className="relative mt-1.5 text-2xl font-black tracking-tight text-text-main">
          {greeting(now.getHours())}، {currentUser?.name?.split(' ')[0] || 'همکار گرامی'}
        </h1>
        <p className="relative mt-1 text-sm text-text-secondary">
          {myTasks.length === 0 && todayCount === 0 ? 'امروز مورد بازی یا برنامه‌ای ندارید؛ می‌توانید با دکمه + کار جدید شروع کنید.' : `${fa(myTasks.length)} وظیفه باز و ${fa(todayCount)} برنامه برای امروز دارید.`}
        </p>
      </section>

      {/* نیاز به اقدام */}
      <section data-tour="needs-action" className="space-y-2.5" aria-label="نیاز به اقدام">
        <SectionTitle title="نیاز به اقدام شما" />
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <StatCard index={0} label="وظایف تأخیردار" value={overdueTasks.length} hint="نیازمند پیگیری فوری" icon={AlertTriangle} tone="danger" onClick={() => navigate('/tasks')} />
          <StatCard index={1} label="تأییدیه‌های منتظر" value={pendingApprovals.length} hint="کارتابل اتوماسیون" icon={CheckSquare} tone="warning" onClick={() => navigate('/internal_automation')} />
          <StatCard index={2} label="وظایف باز من" value={myTasks.length} hint="در انتظار انجام" icon={ListChecks} tone="primary" onClick={() => navigate('/tasks')} />
          <StatCard index={3} label="برنامه امروز" value={todayCount} hint="جلسه و فعالیت" icon={CalendarCheck} tone="success" onClick={() => navigate('/calendar')} />
        </div>
      </section>

      {/* برنامه امروز */}
      <section data-tour="today-schedule" className="space-y-2.5" aria-label="برنامه کاری امروز">
        <SectionTitle title="برنامه کاری امروز" action="مشاهده تقویم" onAction={() => navigate('/calendar')} />
        <div className="space-y-2">
          {todayMeetings.map((m: any) => (
            <div key={m.id} className="se-card flex items-center gap-3 border-e-4 border-e-primary p-3">
              <div className="flex min-w-[52px] flex-col items-center rounded-xl bg-canvas px-2 py-1.5 text-center">
                <span className="text-xs font-bold text-text-main">{m.startTime}</span>
                <span className="text-[10px] text-text-secondary">{m.endTime}</span>
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="truncate text-xs font-bold text-text-main">{m.title}</h3>
                <p className="mt-0.5 flex items-center gap-1 text-[11px] text-text-secondary"><Clock size={11} />جلسه کاری</p>
              </div>
            </div>
          ))}
          {todayActivities.map(a => {
            const acc = state.accounts.find(x => x.id === a.accountId);
            return (
              <div key={a.id} className="se-card flex items-center gap-3 border-e-4 border-e-chart-5 p-3">
                <div className="flex min-w-[52px] flex-col items-center rounded-xl bg-canvas px-2 py-1.5 text-center">
                  <span className="text-xs font-bold text-text-main">{new Date(a.dateTime).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="truncate text-xs font-bold text-text-main">{a.title}</h3>
                  <p className="mt-0.5 flex items-center gap-1 text-[11px] text-text-secondary"><Building2 size={11} /><span className="truncate">{acc?.name || 'مشتری'}</span></p>
                </div>
              </div>
            );
          })}
          {todayCount === 0 && (
            <div className="rounded-2xl border border-dashed border-border-strong bg-white/60 px-4 py-6 text-center text-xs font-medium text-text-secondary">رویداد یا جلسه‌ای برای امروز ثبت نشده است.</div>
          )}
        </div>
      </section>

      {/* مشتریان اخیر */}
      <section data-tour="customer-worklist" className="space-y-2.5" aria-label="مشتریان اخیر">
        <SectionTitle title="مشتریان اخیر" action="همه حساب‌ها" onAction={() => navigate('/accounts')} />
        <div className="space-y-2">
          {recentAccounts.map(acc => (
            <button key={acc.id} onClick={() => navigate(`/accounts/${acc.id}`)}
              className="se-card se-interactive se-pressable flex min-h-[56px] w-full cursor-pointer items-center justify-between p-3 text-start hover:shadow-raised">
              <span className="flex min-w-0 items-center gap-2.5">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-primary/10 text-xs font-bold text-primary">{acc.name ? acc.name.substring(0, 1) : 'م'}</span>
                <span className="min-w-0"><span className="block truncate text-xs font-bold text-text-main">{acc.name}</span><span className="mt-0.5 block truncate text-[11px] text-text-secondary" dir="ltr" style={{ textAlign: 'right' }}>{acc.phone || 'بدون شماره'}</span></span>
              </span>
              <ChevronLeft size={15} className="shrink-0 text-text-secondary" />
            </button>
          ))}
          {recentAccounts.length === 0 && <div className="rounded-2xl border border-dashed border-border-strong bg-white/60 px-4 py-6 text-center text-xs text-text-secondary">هنوز مشتری ثبت نشده است. از دکمه + «مشتری جدید» را بزنید.</div>}
        </div>
      </section>
    </div>
  );
}
