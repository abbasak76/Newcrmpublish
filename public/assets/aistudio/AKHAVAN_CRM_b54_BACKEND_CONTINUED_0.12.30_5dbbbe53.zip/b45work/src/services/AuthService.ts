import { AppState, UserAccount } from '../types';

export type AuthenticationResult =
  | { status: 'AUTHENTICATED'; user: UserAccount }
  | { status: 'INVALID_CREDENTIALS' }
  | { status: 'NOT_CONFIGURED' };

export const AuthService = {
  getCurrentUser(state: AppState): UserAccount | null {
    if (!state.users || state.users.length === 0) return null;
    return state.users.find(u => u.id === state.currentUserId) || state.users[0] || null;
  },
  /** Fail closed until a real server-side identity provider is configured. */
  async authenticate(_credentials: { username: string; password: string }): Promise<AuthenticationResult> {
    // Never validate credentials against local seed/state or simulate a successful sign-in.
    return { status: 'NOT_CONFIGURED' };
  }
};
