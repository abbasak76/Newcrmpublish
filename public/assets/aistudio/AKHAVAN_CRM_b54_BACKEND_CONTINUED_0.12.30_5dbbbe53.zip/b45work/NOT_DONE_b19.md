# NOT DONE — AKHAVAN CRM b19

وضعیت هر بند مستقل است؛ وجود مدل یا فرم، به‌تنهایی معیار تکمیل گردش کاری نیست.

## P0 — تثبیت سورس و تست انتشار
- [ ] اجرای نصب وابستگی‌ها در محیط دارای دسترسی registry.
- [ ] `npm run lint` کامل و رفع خطاهای واقعی TypeScript.
- [ ] `npm run build` و رفع خطاهای build بدون حذف قابلیت.
- [ ] اجرای smoke test در Chromium؛ مسیر `/geo-intelligence`، ایجاد/ویرایش/فعال‌سازی/بایگانی زون، reload، مجوزهای allow/deny و responsive.
- [ ] آزمون واقعی iPhone/Safari، RTL، لمس، overflow، performance و دسترس‌پذیری.
- [ ] اجرای آزمون‌های امنیت منفی با نقش‌های واقعی CEO، مدیر فروش، سرپرست، فروشنده، حسابدار و بازدیدکننده.
- [ ] Backend/API authorization و SQL Server RLS پیش از داده واقعی.

## P1 — هوش مکانی و زون‌ها
- [x] مدل GeoZone/ZoneGeometryVersion/ZoneAssignment/GeoMetricDefinition/ZoneMetricSnapshot در AppState و normalization برای state قدیمی.
- [x] GeoJSON Polygon validation، حداقل 3 رأس متمایز، حلقه بسته، محدوده مختصات و point-in-polygon با احتساب مرز.
- [x] نسخه‌بندی هندسه و حفظ تاریخچه.
- [x] صفحهٔ زون، فرم مختصات، پیش‌نمایش هندسه (نه نقشهٔ واقعی)، نام/کد، وضعیت زون و audit محلی.
- [x] انتساب مشتری داخل polygon برای مشتریان دارای مختصات معتبر و قابل مشاهده طبق RBAC؛ تاریخچه انتساب حفظ می‌شود.
- [x] مجوزهای `geo.view` و `geo.manage` در ماتریس RBAC و تنظیمات پروفایل.
- [ ] ممیزی دقیق نام/منبع مختصات مشتری و کیفیت داده؛ هماهنگ‌سازی با مرزهای واقعی.
- [ ] انتخاب و آزمون MapLibre/tile provider برای ایران، مجوز/هزینه/دسترسی، cache/self-host و چاپ.
- [ ] نقشهٔ واقعی ایران با استان/شهر/راه/برچسب فارسی و ابزار رسم/ویرایش polygon روی نقشه، شامل موبایل.
- [ ] ذخیره/reload زون با تست مرورگر و دستگاه واقعی؛ بررسی polygonهای پیچیده/خودمتقاطع و تاریخ مؤثر.
- [ ] Heatmap تک‌شاخصی با منبع معتبر، واحد، aggregation، زمان تازگی، semantics رنگ و مقایسه دوره.
- [ ] اتصال مطالبات به ماندهٔ معتبر فاکتور − PaymentAllocation − اعتبار؛ فروش به فاکتور معتبر؛ وصول از پرداخت واقعی؛ مرجوعی از سند برگشت معتبر.
- [ ] attribution فیلتر تولیدکننده از خطوط فاکتور و قواعد مالی؛ جلوگیری از نسبت‌دادن کل مانده مشتری به چند تولیدکننده.
- [ ] فیلترهای مشترک و cross-filter نقشه/KPI/جدول/نمودار، drill-down و export.
- [x] ایجاد وظیفهٔ پیگیری وصول از زون برای یک مشتری انتخاب‌شده با مسئول، ناظر اختیاری، مهلت، اولویت و نتیجه مورد انتظار؛ در فهرست وظایف موجود ثبت و از موتور اعلان همکاری استفاده می‌کند.
- [ ] ثبت نتیجهٔ نهایی task: مبلغ وصول معتبر، علت عدم وصول، وضعیت و evidence مجاز؛ GPS به‌تنهایی اثبات انجام کار نیست.
- [ ] ساخت/تخصیص گروهی وظایف از زون بر اساس اولویت مطالبات معتبر و گزارش سلسله‌مراتبی عملکرد.
- [ ] تطبیق planned route با توقف/ویزیت واقعی، تفکیک visit/delivery/failed delivery/return/no-show و گزارش نتیجه واقعی.
- [ ] گزارش سلسله‌مراتبی سازمان→زون→مجری→task→مشتری، چاپ نقشه/فهرست، clustering و تست حجم داده.
- [ ] کنترل scope زون/تیم/قلمرو در تمام فیلترها، taskها، گزارش‌ها و export؛ enforcement در لایه سرور.

## P1 — RBAC و ساختار سازمانی
- [x] پروفایل‌های مجوز قابل تنظیم و ثبت audit محلی.
- [x] scope نقش، workspace پیش‌فرض، نقش بالادست و سرپرست مستقیم قابل تنظیم؛ جلوگیری از چرخه.
- [x] مجوزهای `geo.view` و `geo.manage` مستقل و قابل تنظیم.
- [ ] ویرایشگر کامل `SEE/DO/HIDDEN` برای فیلدها با پوشش واقعی در renderer و API.
- [ ] ممیزی تمام handlerها، exportها، bulk actions، فیلترها و مسیرهای عمیق؛ آزمون تغییر URL/state برای دور زدن مجوز.
- [ ] تست scope سازمان/شعبه/قلمرو/تیم/مالک برای همه ماژول‌ها، مخصوصاً Geo, reports, tasks, finance.
- [ ] backend authentication/authorization و RLS واقعی؛ UI-only guard برای امنیت کافی نیست.

## P1 — سایر گردش‌های تجاری/مالی/داده
- [ ] تطبیق محاسبات مانده و تخصیص با `PaymentAllocation` و تست جلوگیری از دوباره‌شماری پرداخت/چک/اعتبار.
- [ ] تکمیل گردش چک، بانک، هزینه، مغایرت‌گیری، تاریخچه، اصلاح/ابطال و audit end-to-end.
- [ ] تکمیل Quote → acceptance → handoff خارجی → توزیع/تحویل و حفظ `Quote ≠ Order ≠ Invoice`.
- [ ] اتصال KPIها به منابع واحد، تازگی، drill-down، خروجی و تعریف مشترک.
- [ ] تکمیل تصمیم‌یارهای lost-customer, next purchase suggestion, lost-opportunity, anomaly detection و route effectiveness؛ بدون سفارش خودکار و با ثبت قبول/رد/تبدیل پیشنهاد.

## P2 — یکپارچه‌سازی
- [ ] تکمیل API/Auth/DTO/validation، migrations و seed policy در Backend.
- [ ] اجرای migrationها روی SQL Server واقعی، آزمون RLS و recovery.
- [ ] اتصال ERP/ETL با mapping شناسه‌ها، outbox/retry/idempotency، monitoring و reconciliation.
- [ ] آزمون end-to-end با داده/سامانه واقعی؛ تا پیش از آن اتصال واقعی ادعا نشود.
